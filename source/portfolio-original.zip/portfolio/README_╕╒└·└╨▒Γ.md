# 포트폴리오 사이트 업데이트 (2026-08-14)

## 이번에 바뀌는 것
1. **자기소개서 PDF 다운로드 버튼** 추가 (히어로 + Contact 두 곳)
2. **우측 하단 "Designed & built by Kyungrim" 배지** (클릭 시 제작 정보 모달)
3. **갤러리 캡션 수정** — "인수인계 자료" → "2017 Ford 서비스 엑셀런스 프로그램 수상"

## 폴더 안에 있는 파일 (총 3개)

- `index.html`                              → 저장소 루트에 덮어쓰기
- `assets/김경림_자기소개서.pdf`             → 새 파일 (assets 폴더에 추가)
- `assets/styles/tone-c-refinement.css`     → assets/styles 폴더에 덮어쓰기

## 반영 방법 (로컬 저장소 → GitHub)

1. 이 zip을 압축 해제
2. 나온 `portfolio_update` 폴더 안의 파일들을,
   로컬 저장소(portfolio) **같은 위치에 그대로 덮어쓰기**
3. Git 명령어로 push (또는 GitHub Desktop 사용):
   ```
   git add .
   git commit -m "feat: 자기소개서 다운로드 버튼 + 제작자 배지 추가"
   git push
   ```
4. 1~2분 후 https://kyungrim-kim.github.io/portfolio/ 에서 하드 리프레시 (Ctrl+Shift+R)

— Kyungrim, 2026
